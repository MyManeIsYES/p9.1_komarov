package NewClasses
class Class3(var name:String,var num:Int) {

    fun f2(){
        println("мне лень придумывать новую функцию для этого класса, это не где в будущем небудет использоватся,да и непонятно как можно воспользоватся классами")
        println("name: $name")
        println("num: $num")
    }
}
class Class4(var name:String,var str:String) {

    fun f1(){
        println("мне лень придумывать новую функцию для этого класса, это не где в будущем небудет использоватся,да и непонятно как можно воспользоватся классами")
        println("name: $name")
        println("str: $str")
    }
}