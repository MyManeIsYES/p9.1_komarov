package Cinemas
open class Cinema(_movieTitle: String) {
    val movieTitle=_movieTitle
    var session: Int=0
    var ticketPrice: Double=0.0
    var hall: Int=0
    var numberOfViewers:Int=0

    constructor(_movieTitle: String,_session: Int,_ticketPrice: Double,_hall: Int, _numberOfViewers:Int):this(_movieTitle)
    {
        session=_session
        ticketPrice=_ticketPrice
        hall=_hall
        numberOfViewers=_numberOfViewers
    }

    open fun enteringInformation(){
        print("Session: ")
        session= readln()!!.toInt()
        print("ticketPrice: ")
        ticketPrice= readln()!!.toDouble()
        print("Hall: ")
        hall= readln()!!.toInt()
        print("Number of viewers: ")
        numberOfViewers= readln()!!.toInt()
    }

    open fun movieTitle(){
        println("Movie title is \"$movieTitle\".")
    }

    open fun startesSession(time: String){
        println("$movieTitle startes in $time")
    }
    open fun info() : String{
        return "Movie title: $movieTitle\nSession: $session\nTicket price: $ticketPrice\nHall: $hall\nNumber of viewers: $numberOfViewers"
    }


}