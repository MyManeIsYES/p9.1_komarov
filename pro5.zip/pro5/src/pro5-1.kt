//9 зад 12,13
import Products.Product as NewProduct
import Cinemas.Cinema as NewCinema
import NewClasses.*
fun main()=try
{
    print("Выберети класс (1-Cinema,2-Product,3-new): ")
    var a= readln()!!.toInt()
    while (a!=1 && a!=2 && a!=3){
        print("error\nВыберети класс (1-Cinema,2-Product): ")
        a= readln()!!.toInt()
    }

    when(a){
        1->{
            val cino1=NewCinema("cino1",90,9.99,10,100)
            val cino2=NewCinema("cino2")

            cino1.movieTitle()
            cino1.startesSession("16:00")
            println(cino1.info())

            cino2.enteringInformation()
            cino2.startesSession("14:30")
            println(cino2.info())
        }
        2->{
            val Product1=NewProduct("ds",1100)
            val Product2=NewProduct("ddd",777)
            Product1.сhangeProductCharacteristics()
            Product2.сhangeProductCharacteristics()
            Product1.findingTheProduct(1)
            Product2.findingTheProduct(23)
            println(Product1.info())
            println(Product2.info())

            val t1=milk(100,0.6,"DDDDDDD",100)

            println(t1.oilkg(1000.0))
            t1.nameproductTitle(10)
            t1.toxicityLevel(900)
            val t2=oil(10000,10,"DDDDDDD1")
            println(t2.kgg())
            println(t2.info())
            println(t2.oilkg())
        }
        3->{
            val c1=Class3(readln(),1000)
            val c2=Class4(readln(),readln())
            c1.f2()
            c2.f1()
        }
        else->{
            println("error")
        }
    }



}
catch (e:NumberFormatException){println("error")}