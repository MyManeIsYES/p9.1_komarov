import Products.*
class milk(var kg:Int,var oil: Double, empproductTitle:String,ampquantity:Int):Product(empproductTitle,ampquantity) {


    fun oilkg(kg: Double):Double
    {
        return kg*oil
    }
    fun toxicityLevel(discount: Int) {
        println("1")
    }
    fun nameproductTitle(numer:Int){
        println("name: $productTitle №"+numer)
    }


}