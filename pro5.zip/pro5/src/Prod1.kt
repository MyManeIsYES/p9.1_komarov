import Products.*
class oil (var kg:Int,empquantity:Int, empproductTitle:String):Product(empproductTitle,empquantity){

    var n1=empquantity
    fun oilkg():Double
    {
        return (kg*n1)!!.toDouble()
    }
    override fun info():String{
        return "Product title: $productTitle\nPrice: $price\nUnits of measurement: $unitsOfMeasurement\nType of product: $typeOfProduct\nQuantity: $quantity\nkg: $kg"
    }
    fun kgg ():Int{
        return kg*1000
    }


}