package Products
open class Product(var _productTitle:String,var _quantity: Int) {
    var productTitle=_productTitle
    var price=0
    var unitsOfMeasurement=""
    var typeOfProduct=""
    var quantity=_quantity

    constructor(_productTitle:String,_price: Int,_unitsOfMeasurement: String,_typeOfProduct:String,_quantity: Int):this(_productTitle,_quantity){

        price=_price
        unitsOfMeasurement=_unitsOfMeasurement
        typeOfProduct=_typeOfProduct
        quantity=_quantity
    }
    open fun сhangeProductCharacteristics(){
        println("Выберети характеристики товара.")
        print("Product title: ")
        productTitle= readln()!!.toString()
        print("Price: ")
        price= readln()!!.toInt()
        print("Units of measurement: ")
        unitsOfMeasurement= readln()!!.toString()
        print("Type of product: ")
        typeOfProduct= readln()!!.toString()
        print("Quantity: ")
        quantity= readln()!!.toInt()
    }
    open fun findingTheProduct(numerWarehouse:Int){
        println("Product: $productTitle located in the warehouse number $numerWarehouse")
    }


    open fun info():String{
        return "Product title: $productTitle\nPrice: $price\nUnits of measurement: $unitsOfMeasurement\nType of product: $typeOfProduct\nQuantity: $quantity"
    }


}